﻿using System;

namespace DNCD.Data.DataAccess
{
    public class Class1
    {
    }
}
