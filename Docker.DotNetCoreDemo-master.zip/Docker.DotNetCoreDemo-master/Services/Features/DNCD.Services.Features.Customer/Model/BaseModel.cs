﻿namespace DNCD.Services.Features.Customer.Model
{
    public class BaseModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
