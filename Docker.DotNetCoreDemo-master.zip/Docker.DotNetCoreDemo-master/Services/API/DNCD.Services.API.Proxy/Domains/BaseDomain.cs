﻿namespace DNCD.Services.API.Proxy.Domains
{
    public class BaseDomain
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
